from person import Person
from student import Student
from course_scheduler import CourseScheduler
from department_head import DepartmentHead
from advisor import Advisor
from user_json_handler import UserJsonHandler
from typing import List
import os
import logging

class Admin(Person):
    def __init__(self, infos: List[str], admin_id: str):
        # Call superclass constructor with name and advisor_id
        super().__init__(infos[1], admin_id)
        self._user_json = UserJsonHandler()

    def main_menu(self, user_interface):
        user_interface.admin_main_screen()
        
    def add_user(self, username: 'str', password: 'str', user_ID: 'str'):
        self._user_json.create_parameter(username, password, user_ID)
    
    def add_Student(self, name: 'str',student_ID: 'str', advisor_ID: 'str'):
        self._user_json.create_student(name, student_ID, advisor_ID)
        
    def add_Advisor(self, name: 'str', advisor_ID: 'str'):
        self._user_json.create_advisor(name,advisor_ID)
    
    def add_Dep_head(self, name: 'str', Dep_ID: 'str'):
        self._user_json.create_dep_head(name,Dep_ID)
    
    def add_Scheduler(self, name: 'str', scheduler_ID: 'str'):
        self._user_json.create_scheduler(name,scheduler_ID)
        
    def check_user(self)-> 'str':
        logging.basicConfig(level=logging.WARNING, filename="logs.txt", filmode="a", format="%(asctime)s:%(levelname)s:%(message)s")
        while True:
            user_ID = input("Enter ID: ")
            if os.path.isfile(f"jsonfiles/{user_ID}.json"):
                logging.warning("This userID already exists.")
            else:
                return user_ID
                break
    def find_user(self)-> 'str':
        logging.basicConfig(level=logging.WARNING, filename="logs.txt", filmode="a", format="%(asctime)s:%(levelname)s:%(message)s")
        while True:
            user_ID = input("Enter ID: ")
            if os.path.isfile(f"jsonfiles/{user_ID}.json"):
                return user_ID
                break
            else:
                logging.warning("This person doesn't exist.")