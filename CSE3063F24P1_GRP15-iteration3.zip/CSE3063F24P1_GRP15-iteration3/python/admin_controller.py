from login_system_controller import LoginSystemController


class Admin_Controller:

    
    def add_advisor(self,name: 'str', advisor_ID: 'str'):
        log_sys = LoginSystemController.get_login_system()
        admin = log_sys.get_current_user()
        admin.add_Advisor(name,advisor_ID)
    
    def add_Dep_head(self, name: 'str', Dep_ID: 'str'):
        log_sys = LoginSystemController.get_login_system()
        admin = log_sys.get_current_user()
        admin.add_Dep_head(name,Dep_ID)
        
    def add_Schedluer(self,name: 'str', Scheduler_ID: 'str'):
        log_sys = LoginSystemController.get_login_system()
        admin = log_sys.get_current_user()
        admin.add_Scheduler(name,Scheduler_ID)
    
    def add_Student(self, name: 'str', Student_ID: 'str', Advisor_ID: 'str'):
        log_sys = LoginSystemController.get_login_system()
        admin = log_sys.get_current_user()
        admin.add_Student(name,Student_ID, Advisor_ID)
        
    def add_user(self,username: 'str', password: 'str', user_ID: 'str'):
        log_sys = LoginSystemController.get_login_system()
        admin = log_sys.get_current_user()
        admin.add_user(username, password, user_ID)
        
    def check_user(self)-> 'str':
        log_sys = LoginSystemController.get_login_system()
        admin = log_sys.get_current_user()
        return admin.check_user()
        
    
    def find_user(self)-> 'str':
        log_sys = LoginSystemController.get_login_system()
        admin = log_sys.get_current_user()
        return admin.find_user()