from typing import List
from user_json_handler import UserJsonHandler
from person import Person
from transcript import Transcript
from course_section import CourseSection
from student import Student

class Advisor(Person):
    def __init__(self, infos: List[str], advisor_id: str):
        # Call superclass constructor with name and advisor_id
        super().__init__(infos[1], advisor_id)
        self._students: List['Student'] = []
        self._user_json: UserJsonHandler = UserJsonHandler()

    def send_verified_courses(self, transcript: Transcript, verified_courses: List[CourseSection]):
        student = transcript.get_student()
        for course in verified_courses:
            transcript.add_verified_course(course)
            self._user_json.write_verified_course_section(student, course)

    def send_rejected_courses(self, transcript: Transcript, rejected_courses: List[CourseSection]):
        student = transcript.get_student()
        for course in rejected_courses:
            transcript.remove_selected_course(course)
            self._user_json.remove_selected_course_section(student, course)

    def get_student_list(self) -> List[Student]:
        return self._students

    def add_student(self, student: Student):
        self._students.append(student)

    def main_menu(self, user_interface):
        user_interface.advisor_main_screen()
