from typing import List, Set, TYPE_CHECKING

if TYPE_CHECKING:
    from course_section import CourseSection

class Classroom:
    def __init__(self, capacity: int, room_id: str):
        self._capacity: int = capacity
        self._room_id: str = room_id
        self._course_sections: List['CourseSection'] = []

    def check_location_conflict(self, course_section:'CourseSection') -> bool:
        day = course_section.get_day()
        hour = course_section.get_hour()
        start_hour1 = int(hour[:2])
        end_hour1 = int(hour[6:8])
        hour_set1 = set(range(start_hour1, end_hour1 + 1))

        for section in self._course_sections:
            if section.get_day() == day:
                s_hour = section.get_hour()
                start_hour2 = int(s_hour[:2])
                end_hour2 = int(s_hour[6:8])
                hour_set2 = set(range(start_hour2, end_hour2 + 1))
                if hour_set1 & hour_set2:
                    return True
        return False

    def get_room_id(self) -> str:
        return self._room_id
    
    def remove_course_section(self, course_section: 'CourseSection'):
        self._course_sections.remove(course_section)

    def set_room_id(self, room_id: str):
        self._room_id = room_id

    def get_capacity(self) -> int:
        return self._capacity

    def set_capacity(self, capacity: int):
        self._capacity = capacity

    def add_course_section(self, course_section: 'CourseSection'):
        self._course_sections.append(course_section)
