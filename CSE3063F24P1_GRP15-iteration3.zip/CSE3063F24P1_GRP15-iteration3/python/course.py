from typing import TYPE_CHECKING, List, Dict

if TYPE_CHECKING:
    from course_section import CourseSection
    from student import Student
    from transcript import Transcript

class Course:
    def __init__(self, prerequisite_courses: List['Course'] = None, course_code: str = None):
        self._course_sections: List['CourseSection'] = []
        self._prerequisite_courses: List[Course] = prerequisite_courses if prerequisite_courses else []
        self._course_code: str = course_code
        self._year: str = ""
        self._name: str = ""
        self.credits: int=0
        self.technical_elective: bool=0

    def get_name(self) -> str:
        return self._name

    def get_course_code(self) -> str:
        return self._course_code

    def add_prerequisite(self, course: 'Course'):
        self._prerequisite_courses.append(course)

    def set_course_code(self, course_code: str):
        self._course_code = course_code

    def get_course_sections(self) -> List['CourseSection']:
        return self._course_sections

    def add_course_section(self, course_section: 'CourseSection'):
        self._course_sections.append(course_section)

    def check_prerequisites(self, student: 'Student') -> bool:
        transcript: 'Transcript' = student.get_transcript()
        finished_courses: Dict['Course', float] = transcript.get_finished_courses()

        
        if any(course.get_course_code() == self._course_code for course in finished_courses.keys()):
            return False
        for prereq in self._prerequisite_courses:
            if not any(course.get_course_code() == prereq.get_course_code() for course in finished_courses.keys()):
                return False
        
        if self.technical_elective == "1":
            total_credit: int =0
            for course in student.get_transcript().get_finished_courses():
                total_credit += course.get_credit()
            if total_credit < 10:
                return False
        return True

    def set_name(self, name: str):
        self._name = name

    def set_course_sections(self, course_sections: List['CourseSection']):
        self._course_sections = course_sections

    def set_year(self, year: str):
        self._year = year
    def set_credits(self,credits:int):
        self.credits=credits
    def get_credit(self):
        return self.credits

    def get_year(self):
        return self.year
    
    def get_technical_elective(self, technical_elective: 'bool'):
        return self.technical_elective
    def set_technical_elective(self, technical_elective: 'bool'):
        self.technical_elective = technical_elective
