import json
import logging
from typing import List

# Configure logging to write to a file named 'logs'
logging.basicConfig(filename='logs.txt', level=logging.ERROR, 
                    format='%(asctime)s:%(levelname)s:%(message)s')

from course_section import CourseSection
from classroom import Classroom


class CourseJsonHandler:
    def __init__(self):
        self._file_extension: str = ".json"

    def retrieve_info(self, course_id: str) -> List[str]:
        file_path = f"jsonfiles/{course_id}{self._file_extension}"
        result: List[str] = []

        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)

            # Extract course details
            course_type: str = json_content["type"]
            course_name: str = json_content["courseName"]
            academic_year: str = json_content["academicYear"]
            credits:int = json_content["credits"]
            technical_elective: bool = json_content["technical_elective"]

            
            result.extend([course_type, course_name])

            # Extract course sections
            course_sections: List[dict] = json_content["courseSections"]
            sections: List[str] = [
                f"{section['sectionNumber']};{section['day']};{section['time']};{section['room']};{section['capacity']};{section['lecturerID']}"
                for section in course_sections
            ]
            result.append(academic_year)
            result.append(credits)
            result.append("_".join(sections))

            # Extract prerequisites
            prerequisites: List[str] = json_content["prerequisites"]
            prerequisites_string: str = "-".join(prerequisites)
            result.append(prerequisites_string)
            result.append(technical_elective)

        except FileNotFoundError:
            logging.error(f"File not found for course ID {course_id}", exc_info=True)
        except Exception as e:
            logging.error(f"Error reading the JSON file for course: {e}", exc_info=True)

        return result

    def write_capacity(self, course_section: CourseSection, new_capacity: int):
        file_path = f"jsonfiles/{course_section.get_course().get_course_code()}{self._file_extension}"

        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)

            for section in json_content["courseSections"]:
                if section["sectionNumber"] == course_section.get_section_number():
                    section["capacity"] = str(new_capacity)
                    break

            with open(file_path, "w") as file:
                json.dump(json_content, file, indent=2)

        except Exception as e:
            logging.error(f"Error updating capacity: {e}", exc_info=True)

    def write_classroom(self, course_section: CourseSection, new_classroom: str):
        file_path = f"jsonfiles/{course_section.get_course().get_course_code()}{self._file_extension}"

        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)

            for section in json_content["courseSections"]:
                if section["sectionNumber"] == course_section.get_section_number():
                    section["room"] = new_classroom
                    break

            with open(file_path, "w") as file:
                json.dump(json_content, file, indent=2)

        except Exception as e:
            logging.error(f"Error updating classroom: {e}", exc_info=True)

    def write_new_course_section(self, course_section: CourseSection):
        file_path = f"jsonfiles/{course_section.get_course().get_course_code()}{self._file_extension}"

        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)

            new_section: dict = {
                "sectionNumber": len(json_content["courseSections"]) + 1,
                "day": course_section.get_day(),
                "time": course_section.get_hour(),
                "room": course_section.get_classroom().get_room_id(),
                "capacity": str(course_section.get_capacity()),
                "lecturer": "0",
                "waitlist":[]
            }
            json_content["courseSections"].append(new_section)

            with open(file_path, "w") as file:
                json.dump(json_content, file, indent=2)

        except Exception as e:
            logging.error(f"Error adding new course section: {e}", exc_info=True)

    def write_new_classroom_capacity(self, classroom: Classroom, new_capacity: int):
        file_path = f"jsonfiles/classrooms{self._file_extension}"

        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)

            for room in json_content["courseSections"]:
                if room["name"] == classroom.get_room_id():
                    room["capacity"] = new_capacity
                    break

            with open(file_path, "w") as file:
                json.dump(json_content, file, indent=2)

        except Exception as e:
            logging.error(f"Error updating classroom capacity: {e}", exc_info=True)

    def update_course_section_date_and_time(self, course_section: CourseSection, day: str, time: str):
        file_path = f"jsonfiles/{course_section.get_course().get_course_code()}{self._file_extension}"

        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)

            for section in json_content["courseSections"]:
                if section["sectionNumber"] == course_section.get_section_number():
                    section["day"] = day
                    section["time"] = time
                    break

            with open(file_path, "w") as file:
                json.dump(json_content, file, indent=2)

        except Exception as e:
            logging.error(f"Error updating course section date and time: {e}", exc_info=True)
    def add_course(self, course_code: str, course_name: str, prerequisites: list[str], academic_year: str, credits: int,is_technical_elective:int):
        # Create the course dictionary
        te = "false"
        

        course_data = {
            "type": "Course",
            "prerequisites": prerequisites,
            "credits": str(credits),
            "courseName": course_name,
            "academicYear": academic_year,
            "courseSections": [],
            "technical_elective": is_technical_elective
        }

        # Define the file path
        file_path = f"jsonfiles/{course_code}.json"

        # Write the course data to a JSON file
        with open(file_path, 'w') as json_file:
            json.dump(course_data, json_file, indent=2)
        file_path_2 = f"jsonfiles/courses.json"
        try:
            with open(file_path_2, "r") as file:
                json_content = json.load(file)

            new_course = {
                "code": course_code
            }
            json_content.append(new_course)

            with open(file_path_2, "w") as file:
                json.dump(json_content, file, indent=2)
        except Exception as e:
            logging.error(f"Error adding course to courses.json: {e}", exc_info=True)
    def write_waiting_student(self, course_section: CourseSection, waiting_student_id:str):
        file_path = f"jsonfiles/{course_section.get_course().get_course_code()}.json"

        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)

            for section in json_content["courseSections"]:
                if section["sectionNumber"] == course_section.get_section_number():
                    if waiting_student_id not in section["waitlist"]:
                        section["waitlist"].append(waiting_student_id)
                    break

            with open(file_path, "w") as file:
                json.dump(json_content, file, indent=2)

        except Exception as e:
            logging.error(f"Error writing waiting student: {e}", exc_info=True)
    def remove_waiting_student(self, course_section: CourseSection, waiting_student_id:str):
        file_path = f"jsonfiles/{course_section.get_course().get_course_code()}.json"

        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)

            for section in json_content["courseSections"]:
                if section["sectionNumber"] == course_section.get_section_number():
                    if waiting_student_id in section["waitlist"]:
                        section["waitlist"].remove(waiting_student_id)
                    break

            with open(file_path, "w") as file:
                json.dump(json_content, file, indent=2)

        except Exception as e:
            logging.error(f"Error removing waiting student: {e}", exc_info=True)
    
    def write_section_to_lecturer(self, course_section: CourseSection, lecturer_ID: str):
        file_path = f"jsonfiles/lecturers.json"

        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)

            for lecturer in json_content[""]:
                if lecturer["lecturerID"] == lecturer_ID:
                    lecturer["givenCourseSections"].append(course_section.get_course().get_course_code() + "." + course_section.get_id())
                    break

            with open(file_path, "w") as file:
                json.dump(json_content, file, indent=2)

        except Exception as e:
            print(f"Error updating classroom: {e}")
    
    def write_lecturer_to_section(self, course_section: CourseSection, lecturer_ID: str):

        file_path = f"jsonfiles/{course_section.get_course().get_course_code}.json"

        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)

            for section in json_content["courseSections"]:
                if section["sectionNumber"] == course_section.get_section_number:
                    section["lecturerID"] = lecturer_ID
                    break

            with open(file_path, "w") as file:
                json.dump(json_content, file, indent=2)

        except Exception as e:
            logging.error(f"Error updating classroom: {e}", exec_info=True)