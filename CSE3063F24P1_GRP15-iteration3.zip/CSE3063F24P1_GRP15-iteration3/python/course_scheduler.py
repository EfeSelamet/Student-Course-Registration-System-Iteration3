from typing import List
from typing import TYPE_CHECKING
from classroom import Classroom
from course import Course
from person import Person
if TYPE_CHECKING:
    from course_section import CourseSection
    from course_json_handler import CourseJsonHandler
    from registration_controller import RegistrationController
    from user_interface import UserInterface
    from lecturer import Lecturer
    from typing import Set


class CourseScheduler(Person):
    def __init__(self, info: List[str], scheduler_id: str):
        super().__init__(info[1], scheduler_id)

    def _check_semester_conflict(self, section: 'CourseSection', time: str, date: str) -> bool:
        # Placeholder for conflict checking logic
        semester = str(section.get_course().get_year())
        list_of_courses = RegistrationController.get_registration_controller().get_all_courses()
        hour_set2: Set[int] = set()
        start_hour2 = int(time[:2])
        end_hour2 = int(time[6:8])

        for b in range(start_hour2, end_hour2 + 1):
            hour_set2.add(b)

        for course in list_of_courses:
            if course.get_year() == semester:

                for section in course.get_course_sections:
                    if section.get_day == date:
                        start_hour = int(section.get_hour()[:2])
                        end_hour = int(section.get_hour()[6:8])
                        for a in range(start_hour, end_hour + 1):
                            if hour_set2.__contains__(a):
                                return True
        return False

    def edit_section_time(self, section: 'CourseSection', time: str, date: str) -> bool:
        if section.get_classroom().check_location_conflict(time, date):
            return False

        if self._check_semester_conflict(section, time, date):
            return False

        section.set_day(date)
        section.set_hour(time)

        course_json_handler: 'CourseJsonHandler' = CourseJsonHandler()
        course_json_handler.update_course_section_date_and_time(section, date, time)

        return True


    def edit_section_class(self, section: 'CourseSection', classroom: 'Classroom') -> bool:
        if classroom.check_location_conflict(section):
            return False

        section.set_classroom(classroom)

        classroom.add_course_section(section)    
        

        return True

    def edit_section_capacity(self, section: 'CourseSection', capacity: int) -> bool:
        section.set_capacity(capacity)
        

    def add_section(self, courseObj:'Course', classroom:'Classroom', course_section:'CourseSection') -> bool:
        
        if classroom.check_location_conflict(course_section):
            raise ValueError("Location conflict detected.")
        

        
        courseObj.add_course_section(course_section)
        classroom.add_course_section(course_section)
        return True

    def add_lecturer(self, course_Section : 'CourseSection', lecturer : 'Lecturer') -> bool:
            if lecturer.check_lecturer_conflict(course_Section.get_day, course_Section.get_hour):
                lecturer.add_course_section(course_Section)
                course_Section.set_lecturer(lecturer)
            

    def main_menu(self, user_interface: 'UserInterface'):
        user_interface.scheduler_main_screen()
