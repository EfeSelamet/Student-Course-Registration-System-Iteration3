from typing import Optional, Deque
from collections import deque
from course import Course
from typing import TYPE_CHECKING
import logging

if TYPE_CHECKING:
    from classroom import Classroom
    from student import Student
    from lecturer import Lecturer

class CourseSection:
    def __init__(self, day: str, hour: str, section_number: int, course: 'Course', classroom: 'Classroom', capacity: int, lecturer: 'Lecturer'):
        self._day: str = day
        self._hour: str = hour
        self._section_number: int = section_number
        self._capacity: int = capacity
        
        self._id: str = f"{course.get_course_code()}.{section_number}"
        self._number_of_students: int = 0
        
        self._course: Optional[Course] = course
        self._classroom: Optional[Classroom] = classroom
        self._waiting_students: Deque[Student] = deque()
        self._lecturer: Optional[Lecturer] = lecturer

    def set_classroom(self, classroom: 'Classroom'):
        self._classroom = classroom

    def set_day(self, day: str):
        self._day = day

    def set_hour(self, hour: str):
        self._hour = hour
    def enroll(self):
        self._number_of_students+=1
    def get_classroom(self) -> 'Classroom':
        return self._classroom

    def get_capacity(self) -> int:
        return self._capacity

    def get_course(self) -> 'Course':
        return self._course

    def get_day(self) -> str:
        return self._day

    def get_hour(self) -> str:
        return self._hour

    def get_section_number(self) -> int:
        return self._section_number

    def get_waiting_students(self) -> Deque['Student']:
        return self._waiting_students

    def set_section_number(self, section_number: int):
        self._section_number = section_number

    def get_id(self) -> str:
        return self._id

    def set_capacity(self, new_capacity: int):
        if new_capacity < self._number_of_students:
            raise ValueError("New capacity is less than the number of students enrolled.")
            logging.error("New capacity is less than the number of students enrolled.")
        self._capacity = new_capacity

    def get_number_of_students(self) -> int:
        return self._number_of_students

    def set_number_of_students(self, number_of_students: int):
        self._number_of_students = number_of_students

    def set_id(self, section_id: str):
        self._id = section_id

    def set_course(self, course: 'Course'):
        self._course = course

    def set_lecturer(self, lecturer: 'Lecturer'):
        self._lecturer = lecturer
    
    def get_lecturer(self) -> 'Lecturer':
        return self._lecturer
