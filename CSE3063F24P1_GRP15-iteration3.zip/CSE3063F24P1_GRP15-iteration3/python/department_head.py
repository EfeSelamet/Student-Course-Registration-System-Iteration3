from typing import TYPE_CHECKING, List
from course import Course
from course_section import CourseSection
from person import Person
import json


if TYPE_CHECKING:
    from user_interface import UserInterface


class DepartmentHead(Person):
    def __init__(self, infos: List[str], department_head_id: str):
        super().__init__(infos[1], department_head_id)

    
    def create_course(self, course_code: str, course_name: str, prerequisites: list[Course], academic_year: str, credits: int, technical_elective: int):
        from registration_controller import RegistrationController
        course = Course()
        course.set_course_code(course_code)
        course.set_name(course_name)
        course.set_credits(credits)
        for c in prerequisites:
            course.add_prerequisite(c)
        course.set_year(academic_year)
        course.set_technical_elective(technical_elective)
        RegistrationController.get_registration_controller().get_all_courses().append(course)
    def increase_course_capacity(self, coursesection: 'CourseSection', capacity: int):
        
        coursesection.set_capacity(capacity)

    def main_menu(self, user_interface: 'UserInterface'):
        user_interface.department_head_main_screen()

    
        




