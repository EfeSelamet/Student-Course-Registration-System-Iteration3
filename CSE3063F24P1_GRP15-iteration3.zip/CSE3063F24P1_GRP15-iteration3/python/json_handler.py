from typing import List
from abc import ABC, abstractmethod


class JsonHandler(ABC):
    @abstractmethod
    def retrieve_info(self, id: str) -> List[str]:
        pass
