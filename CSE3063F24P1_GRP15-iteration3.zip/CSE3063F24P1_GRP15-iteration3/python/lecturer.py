from typing import List
from typing import Set
from user_json_handler import UserJsonHandler
from person import Person
from course_section import CourseSection

class Lecturer():
    def __init__(self, name: str , lecturer_id: str, course_sections: List[str]):
        self._course_sections: List[str] = course_sections  # List of courseSection
        self._name: str = name
        self._lecturer_id: str = lecturer_id

    def add_course_section(self, course_section: CourseSection):
        self._course_sections.append(course_section)
            
    def check_lecturer_conflict(self, day: str, hour: str) -> bool:
        hour_set1: Set[int] = set()
        start_hour1 = int(hour[:2])
        end_hour1 = int(hour[6:8])
        for b in range(start_hour1, end_hour1 + 1):
            hour_set1.add(b)

        for section in self.course_sections:
            if section.get_day == day:
                start_hour2 = int(section.get_hour()[:2])
                end_hour2 = int(section.get_hour()[6:8])
                # Populate hour_set1 with hours in range
                for a in range(start_hour2, end_hour2 + 1):
                    if hour_set1.__contains__(a):
                        return True
        return False     
    def get_lecturer_id(self) -> str:
        return self._lecturer_id
