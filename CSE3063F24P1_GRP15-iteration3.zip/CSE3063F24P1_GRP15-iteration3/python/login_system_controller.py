import logging
from typing import List, Optional
from department_head import DepartmentHead
from person import Person
from student import Student
from advisor import Advisor
from course_scheduler import CourseScheduler
from student_affairs import StudentAffairs
from user_json_handler import UserJsonHandler
from admin import Admin
class LoginSystemController:
    _login_system: Optional["LoginSystemController"] = None

    def __init__(self):
        # Initialize as a singleton instance
        LoginSystemController._login_system = self
        self._current_user: Optional[Person] = None
        logging.info("Login system controller inittilazied")

    @staticmethod
    def get_login_system() -> "LoginSystemController":
        return LoginSystemController._login_system

    def login(self, username: str, password: str) -> bool:
        ujs = UserJsonHandler()
        user_id = ujs.check_user(username, password)
        if not user_id:
            return False

        self._current_user = self._create_user(user_id)
        return True

    def _create_user(self, user_id: str) -> Optional[Person]:
        ujs = UserJsonHandler()
        info = ujs.retrieve_info(user_id)

        if info[0] == "student":
            student = Student(info, user_id)
            advisor = self._create_user(info[2])  # Recursively create the advisor
            if isinstance(advisor, Advisor):
                student.set_advisor(advisor)
            return student

        if info[0] == "advisor":
            advisor = Advisor(info, user_id)
            student_ids = info[2].split(",")
            for student_id in student_ids:
                student = self._create_student_without_advisor(student_id)
                advisor.add_student(student)
            return advisor

        if info[0] == "scheduler":
            course_scheduler = CourseScheduler(info, user_id)
            return course_scheduler
        if info[0]=="dep_head":
            dep_head=DepartmentHead(info,user_id)
            return dep_head
        
        if info[0]=="student_affairs":
            dep_head=StudentAffairs(info,user_id)
            return dep_head
        if info[0]=="admin":
            admin=Admin(info,user_id)
            return admin
        logging.error("User type not recognized")
        return None

    def _create_student_without_advisor(self, user_id: str) -> Student:
        ujs = UserJsonHandler()
        info = ujs.retrieve_info(user_id)
        student = Student(info, user_id)
        return student
    
    
            
    def send_notification_to_id(self, id : str, message : str):
        studentAffairs : StudentAffairs = self._current_user
        student = self._create_user(id)
        studentAffairs.send_notification(student, message)

    def send_notification_to_all(self, message : str):
        user_json = UserJsonHandler()
        student_ids = user_json.get_all_student_ids()

        for id in student_ids:
            self.send_notification_to_id(id , message)


    def get_current_user(self) -> Optional[Person]:
        return self._current_user

    def logout(self):
        self._current_user = None
