from abc import ABC, abstractmethod
from typing import Optional

class Person(ABC):
    def __init__(self, full_name: str, person_id: str):
        self._full_name: str = full_name
        self._id: str = person_id

    def get_id(self) -> str:
        return self._id

    def get_full_name(self) -> str:
        return self._full_name

    @abstractmethod
    def main_menu(self, user_interface):
        pass
