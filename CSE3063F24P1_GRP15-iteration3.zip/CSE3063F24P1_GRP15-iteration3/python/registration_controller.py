import json
import logging
import os
from typing import TYPE_CHECKING, List, Optional
from classroom import Classroom
from lecturer import Lecturer
from course_json_handler import CourseJsonHandler
from course import Course
from course_section import CourseSection
from user_json_handler import UserJsonHandler
   

class RegistrationController:
    _registration_controller: Optional["RegistrationController"] = None

    def __init__(self):
        # Singleton instance
        RegistrationController._registration_controller = self
        self._all_courses: List[Course] = []
        self._all_classrooms: List[Classroom] = []
        self._all_lecturers: List[Lecturer] = []

        # Load classrooms
        self._load_classrooms("jsonfiles/classrooms.json")
        logging.info("All classrooms loaded succesfully")
        self._load_lecturers("jsonfiles/lecturers.json")
        logging.info("All lecturers loaded succesfully")
        # Load courses
        self._load_courses("jsonfiles/courses.json")
        logging.info("All courses loaded succesfully")

    def _load_classrooms(self, file_path: str):
        try:
            with open(file_path, "r") as file:
                classrooms = json.load(file)
            logging.info("Classroom file opened succesfully")
            for classroom in classrooms:
                name = classroom["name"]
                capacity = int(classroom["capacity"])
                self._all_classrooms.append(Classroom(capacity, name))
                logging.debug(f"{name} classrom  with {capacity} capacity initilazied")

        except FileNotFoundError as e:
            logging.error(f"Classroom file not found: {e}", exc_info=True)
            raise RuntimeError(f"Classroom file not found: {e}")
        
    def _load_lecturers(self, file_path: str):
        try:
            with open(file_path, "r") as file:
                lecturers = json.load(file)
                logging.info("Lecturer file opened succesfully")

            for lecturer in lecturers:
                name = lecturer["name"]
                lecturerID = lecturer["lecturerID"]
                given_course_sections = list(lecturer["givenCourseSections"])
                self._all_lecturers.append(Lecturer(name, lecturerID, given_course_sections))
                logging.debug(f"{name} lecturer with {lecturerID} id initilazied")
        except FileNotFoundError as e:
            raise RuntimeError(f"Lecturer file not found: {e}")

    def _load_courses(self, file_path: str):
        course_json_handler = CourseJsonHandler()
        course_codes = []

        try:
            with open(file_path, "r") as file:
                courses = json.load(file)
                logging.info("Course file opened succesfully")

            for course in courses:
                course_codes.append(course["code"])

        except FileNotFoundError as e:
            logging.error(f"Course file not found: {e}", exc_info=True)
            raise RuntimeError(f"Course file not found: {e}")

        for course_code in course_codes:
            if course_code in [ci.get_course_code for ci in self._all_courses]:
                continue
            infos = course_json_handler.retrieve_info(course_code)

            logging.debug(f"Course will be initilazied with {infos}")
            course = Course()
            course.set_name(infos[1])
            course.set_year(infos[2])
            course.set_credits(infos[3])
            course.set_course_code(course_code)
            course.set_technical_elective(infos[6])
            self._all_courses.append(course)  
            if not (infos[4] == "" or infos[4] == None):
                sections = infos[4].split("_")
            # Add course sections
            
            for section in sections:
                section_info = section.split(";")
                course_section = CourseSection(section_info[1], section_info[2],section_info[0],course, None, int(section_info[4]),"0")
                # Set capacity from JSON
                if len(section_info) > 4:
                    course_section.set_capacity(int(section_info[4]))
                # Load waiting list from the JSON file
                self._load_waitlist(course_section)
                if section_info[5] != "0":
                    course_section.set_lecturer(section_info[5])
             

                    # Assign classroom
                    for classroom in self._all_classrooms:
                        if classroom.get_room_id() == section_info[3]:
                            classroom.add_course_section(course_section)
                            course_section.set_classroom(classroom)

                course.add_course_section(course_section)

            

            # Add prerequisites
            prerequisites = infos[5].split("-")
            if prerequisites and prerequisites[0]:
                for prerequisite_code in prerequisites:
                    prerequisite_info = course_json_handler.retrieve_info(prerequisite_code)
                    prerequisite = Course()
                    prerequisite.set_name(prerequisite_info[1])
                    prerequisite.set_year(prerequisite_info[2])
                    prerequisite.set_course_code(prerequisite_code)
                    course.add_prerequisite(prerequisite)

            logging.debug(f"Course {course.get_name()} with {course.get_course_code()} id, {course.get_name()} innitilazied")

    def _load_waitlist(self, course_section: 'CourseSection'):
        """
        Reads waitlist from the course's JSON and appends Student objects.
        """
        import json
        from user_json_handler import UserJsonHandler
        from login_system_controller import LoginSystemController
        
        course_code = course_section.get_course().get_course_code()
        path = f"jsonfiles/{course_code}.json"
        try:
            with open(path, "r") as f:
                data = json.load(f)
            
            for s in data["courseSections"]:
                if str(s["sectionNumber"]) == str(course_section.get_section_number()):
                    for student_id in s["waitlist"]:

                        student_obj = LoginSystemController.get_login_system()._create_user(student_id)
                        if student_obj:
                            course_section.get_waiting_students().append(student_obj)
                    break
        except FileNotFoundError:
            pass

    def get_course_section_from_id(self, section_id: str) -> Optional[CourseSection]:
        for course in self._all_courses:
            for section in course.get_course_sections():
                if section.get_id() == section_id:
                    return section
        return None
    
    def get_course_from_id(self, course_id: str) -> Optional[Course]:
        for course in self._all_courses:
            if course.get_course_code() == course_id:
                return course
        return None

    def get_available_courses(self, student) -> List[Course]:
    
        return student.get_available_courses(self._all_courses)
        
    def send_selected_courses(self, selected_course_sections:List['CourseSection'], current_user:'Student'):
        current_user.update_selected_courses(selected_course_sections)
        
        json_handler = UserJsonHandler()
        json_handler.write_all_selected_courses(current_user, selected_course_sections)

    def put_student_on_waiting_list(self, student: 'Student', course_section: 'CourseSection'):
        course_section.get_waiting_students().append(student)
        csj = CourseJsonHandler()
        csj.write_waiting_student(course_section, student.get_id())
    @staticmethod
    def get_registration_controller() -> "RegistrationController":
        return RegistrationController._registration_controller
    def get_all_courses(self) -> List[Course]:
        return self._all_courses
    def get_all_classrooms(self) -> List[Classroom]:
        return self._all_classrooms
    def get_all_lecturers(self) -> List[Lecturer]:
        return self._all_lecturers