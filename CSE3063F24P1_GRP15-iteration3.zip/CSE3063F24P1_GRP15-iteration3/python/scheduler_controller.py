import logging
from course_json_handler import CourseJsonHandler
from login_system_controller import LoginSystemController
from registration_controller import RegistrationController
from typing import TYPE_CHECKING
from department_head import DepartmentHead
from lecturer import Lecturer
from course_scheduler import CourseScheduler
# Configure logging to write to a file named 'logs'
logging.basicConfig(filename='logs.txt', level=logging.ERROR, 
                    format='%(asctime)s:%(levelname)s:%(message)s')

if TYPE_CHECKING:
    from classroom import Classroom
    from student import Student
    from lecturer import Lecturer
    from course_section import CourseSection
    from admin import Admin
    


class SchedulerController:
    def view_courses(self):
        list_of_courses = RegistrationController.get_registration_controller().get_all_courses()
        course_list = ""
        number = 1

        for course in list_of_courses:
            course_list += f"{number}. {course.get_course_code()} {course.get_name()}\n"
            number += 1

        return course_list

    def view_course_sections(self, index:int):
        list_of_courses = RegistrationController.get_registration_controller().get_all_courses()
        if index < 1 or index > len(list_of_courses):
            return None

        selected_course = list_of_courses[index - 1]
        section_list = ""
        number = 1

        for section in selected_course.get_course_sections():
            section_list += (
                f"{number}. {section.get_id()} {section.get_day()} {section.get_hour()} "
                f"Capacity: {section.get_capacity()}\n"
            )
            number += 1

        return section_list

    def edit_section_capacity(self, course:int, section:int, capacity:int):
        from user_json_handler import UserJsonHandler
        list_of_courses = RegistrationController.get_registration_controller().get_all_courses()
        person = LoginSystemController.get_login_system().get_current_user()
        list_of_sections = list_of_courses[course - 1].get_course_sections()
        if section < 1 or section > len(list_of_sections):
            raise Exception("you have entered wrong section number")

        course_section = list_of_sections[section - 1]
        old_capacity = course_section.get_capacity()
        course_section.set_capacity(capacity)
        csj = CourseJsonHandler()
        
        if capacity > old_capacity:
            for i in range(capacity - old_capacity):
                if len(course_section.get_waiting_students()) > 0:
                    student = course_section.get_waiting_students().popleft()
                    student.get_transcript().add_selected_course(course_section)
                    UserJsonHandler().write_selected_courses_section(student, course_section)
                    csj.remove_waiting_student(course_section, student.get_id())
                    UserJsonHandler().write_notification(
                        student,
                        f"You have been enrolled in {course_section.get_id()} because capacity was increased."
                    )
        elif course_section.get_number_of_students<capacity:
            raise Exception("new capacity should be more than number of student which have already taken this course.")

        
        
        csj.write_capacity(course_section, capacity)

        if isinstance(person, DepartmentHead):
            person.increase_course_capacity(course_section, capacity)
        elif isinstance(person, CourseScheduler):
            
            person.edit_section_capacity(course_section, capacity)
        return True

    def edit_section_time(self, course:int, section:int, time:int, date:str):
        list_of_courses = RegistrationController.get_registration_controller().get_all_courses()
        list_of_sections = list_of_courses[course - 1].get_course_sections()
        scheduler = LoginSystemController.get_login_system().get_current_user()
        if section < 1 or section > len(list_of_sections):
            return False

        course_section = list_of_sections[section - 1]
        return scheduler.edit_section_time(course_section, time, date)

    def edit_section_class(self, course:int, section:int, classroom:str):
        list_of_courses = RegistrationController.get_registration_controller().get_all_courses()
        all_classrooms = RegistrationController.get_registration_controller().get_all_classrooms()
        scheduler = LoginSystemController.get_login_system().get_current_user()
        list_of_sections = list_of_courses[course - 1].get_course_sections()
        
        if section < 1 or section > len(list_of_sections):
            return False

        csj = CourseJsonHandler()
        course_section = list_of_sections[section - 1]
        old_classroom = course_section.get_classroom()
        old_classroom.remove_course_section(course_section)

        for cr in all_classrooms:
            if cr.get_room_id() == classroom:
                if cr.get_capacity() < course_section.get_capacity():
                    logging.warning("course section capacity will exceed class capacity")
                    cr.set_capacity(course_section.get_capacity())
                    csj.write_new_classroom_capacity(cr, course_section.get_capacity())

                cr.add_course_section(course_section)
                course_section.set_classroom(cr)
                break

        csj.write_classroom(course_section, classroom)
        scheduler.edit_section_class(course_section, classroom)
        return True

    def add_course_section(self, course:int,classroom:str, hour:str, day:str):
        from course_section import CourseSection
        list_of_courses = RegistrationController.get_registration_controller().get_all_courses()
        list_of_classrooms = RegistrationController.get_registration_controller().get_all_classrooms()
        csj = CourseJsonHandler()
        course_index = int(course)
        if course_index < 1 or course_index > len(list_of_courses):
            return False


        
        
        selected_course = list_of_courses[course_index - 1]
       
        for cr in list_of_classrooms:
            if cr.get_room_id() == classroom:
                
                break
        course_section = CourseSection(day,hour,len(selected_course.get_course_sections())+1,selected_course,cr,0)
       
        scheduler = LoginSystemController.get_login_system().get_current_user()
        csj.write_new_course_section(course_section)
        return scheduler.add_section(selected_course,  cr,course_section)
    def create_course(self, course_code: str, course_name: str, prerequisites: list[str], academic_year: str, credits: int,technical_elective:int):
        
        from registration_controller import RegistrationController
        from course_json_handler import CourseJsonHandler
        from login_system_controller import LoginSystemController
        depHead = LoginSystemController.get_login_system().get_current_user()
        
        preqList = []
        for p in prerequisites:
            p_obj = RegistrationController.get_registration_controller().get_course_from_id(p)
            preqList.add_prerequisite(p_obj)

        csj = CourseJsonHandler()
        csj.add_course(course_code, course_name, prerequisites, academic_year, credits,technical_elective)
        depHead.create_course(course_code, course_name, preqList, academic_year, credits, technical_elective)    
    
    def edit_section_lecturer(self, course:str, section:int, lecturer:str):
        list_of_sections = RegistrationController.get_registration_controller().get_course_from_id(course)
        section = list_of_sections[section - 1]
        if section < 1 or section > len(list_of_sections):
            return False
        

        reg = RegistrationController()
        _all_lecturers=reg.get_all_lecturers()
        _lecturer:Lecturer= None
        for lecturer in _all_lecturers:
            if lecturer.get_lecturer_id():
                _lecturer=lecturer
                break
        if _lecturer is None:
            raise Exception("This lecturer ID isn't exist.")
        csj = CourseJsonHandler()
        section_time = str(section.get_hour())
        section_day = str(section.get_day())
        if _lecturer.check_lecturer_conflict(section_day, section_time):
            return False
        else:
            _lecturer.add_course_section(section)
            csj.write_section_to_lecturer(section, _lecturer.get_lecturer_id())
            section.set_lecturer(_lecturer)
            csj.write_lecturer_to_section(section, _lecturer.get_lecturer_id())
            return True
            
    