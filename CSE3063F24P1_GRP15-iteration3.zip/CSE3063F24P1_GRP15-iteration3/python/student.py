from typing import TYPE_CHECKING, List, Optional, Dict
from person import Person
from transcript import Transcript
if TYPE_CHECKING:
    from advisor import Advisor
    from course import Course
    from course_section import CourseSection
    
    from user_interface import UserInterface
class Student(Person):
    def __init__(self, infos: List[str], student_id: str):
        super().__init__(infos[1], student_id)
        self._advisor: Optional['Advisor'] = None
        self._transcript: 'Transcript' = self._create_transcript(infos[3], infos[4], infos[5])

    def update_selected_courses(self, selected_courses: List['CourseSection']):
        for section in selected_courses:
            if section.get_capacity() > section.get_number_of_students():
                self._transcript.add_selected_course(section)
                section.set_number_of_students(section.get_number_of_students() + 1)
            else:
                section.get_waiting_students().append(self)

    def get_available_courses(self, all_courses: List['Course']) -> List['Course']:
        available_courses: List[Course] = []
        for course in all_courses:
            if course.check_prerequisites(self):
                available_courses.append(course)
        selected_courses = self._transcript.get_selected_courses()
        for course in available_courses:
            if any(course.get_course_code() == selected.get_course().get_course_code() for selected in selected_courses):
                available_courses.remove(course)
        return available_courses

    def get_advisor(self) -> 'Advisor':
        return self._advisor

    def get_transcript(self) -> 'Transcript':
        return self._transcript

    def retrieve_selected_courses(self) -> List['CourseSection']:
        return self._transcript.get_selected_courses()

    def set_advisor(self, advisor: 'Advisor'):
        self._advisor = advisor

    def _create_transcript(self, selected: str, verified: str, finished: str) -> 'Transcript':
        from registration_controller import RegistrationController
        registration_controller = RegistrationController.get_registration_controller()

        selected_course_section_ids = selected.split(",")
        verified_course_section_ids = verified.split(",")
        finished_courses = finished.split(",")

        selected_course_sections: List[CourseSection] = [
            registration_controller.get_course_section_from_id(cs_id)
            for cs_id in selected_course_section_ids if cs_id
        ]
        verified_course_sections: List[CourseSection] = [
            registration_controller.get_course_section_from_id(cs_id)
            for cs_id in verified_course_section_ids if cs_id
        ]

        finished_courses_map: Dict[Course, float] = {}
        for course_data in finished_courses:
            if course_data:
                course_id, grade = course_data.split("-")
                finished_courses_map[
                    registration_controller.get_course_from_id(course_id)
                ] = float(grade)

        return Transcript(selected_course_sections, verified_course_sections, finished_courses_map, self)

    def main_menu(self, user_interface: 'UserInterface'):
        user_interface.student_main_screen()
