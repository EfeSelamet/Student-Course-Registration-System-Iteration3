from typing import TYPE_CHECKING
from typing import List
from person import Person
from user_json_handler import UserJsonHandler
if TYPE_CHECKING:
    from student import Student
    from user_interface import UserInterface

class StudentAffairs(Person):
    def __init__(self, infos: List[str], affair_id: str):
        # Call superclass constructor with name and advisor_id
        super().__init__(infos[1], affair_id)


    def main_menu(self, user_interface: 'UserInterface'):
        user_interface.student_affair_menu()

    def send_notification(self, student : 'Student', message : str):
        user_json = UserJsonHandler()
        user_json.write_notification(student, message)
