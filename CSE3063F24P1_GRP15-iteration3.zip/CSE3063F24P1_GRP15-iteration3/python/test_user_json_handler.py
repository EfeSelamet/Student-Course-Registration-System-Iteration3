import unittest
import os
import json
from user_json_handler import UserJsonHandler

class TestUserJsonHandler(unittest.TestCase):

    def setUp(self):
        self.handler = UserJsonHandler()
        self.test_json = 'test_parameters.json'
        with open(self.test_json, 'w') as file:
            json.dump([], file)  # Initialize with empty list
        self.handler._parameters = self.test_json  # Point to the test file

    def tearDown(self):
        if os.path.exists(self.test_json):
            os.remove(self.test_json)

    def test_create_parameter_and_check_user(self):
        # Test adding user credentials and then validating them
        self.handler.create_parameter('testuser', 'testpass', 'testid')
        result = self.handler.check_user('testuser', 'testpass')
        self.assertEqual(result, 'testid')

    def test_invalid_credentials(self):
        self.handler.create_parameter('validuser', 'validpass', 'validid')
        result = self.handler.check_user('invaliduser', 'invalidpass')
        self.assertEqual(result, '')

    def test_multiple_users(self):
        new_json = 'test_extra_parameters.json'
        with open(new_json, 'w') as file:
            json.dump([], file)
        self.handler._parameters = new_json

        self.handler.create_parameter('user1', 'pass1', 'id1')
        self.handler.create_parameter('user2', 'pass2', 'id2')
        self.assertEqual(self.handler.check_user('user1', 'pass1'), 'id1')
        self.assertEqual(self.handler.check_user('user2', 'pass2'), 'id2')

        if os.path.exists(new_json):
            os.remove(new_json)

    def test_missing_file_scenario(self):
        if os.path.exists(self.test_json):
            os.remove(self.test_json)
        result = self.handler.check_user('user', 'pass')
        self.assertEqual(result, '')

    def test_write_and_pull_notifications(self):
        test_notifications_json = 'test_notifications.json'
        with open(test_notifications_json, 'w') as file:
            json.dump({"notifications": []}, file)
        student_id = 'notifTest'
        self.handler.write_notification_type = test_notifications_json  # Use a temp file or mock
        # ...existing code...
        self.handler.write_notification_type = test_notifications_json  # Hypothetical attribute to redirect for test
        self.handler.write_notification_type = None  # Reset if needed

    def test_create_advisor_temporary(self):
        test_advisor_json = 'test_advisor.json'
        if os.path.exists(test_advisor_json):
            os.remove(test_advisor_json)
        self.handler.create_advisor('tempAdvisor', 'tempID')
        self.assertTrue(os.path.exists('jsonfiles/tempID.json'))
        if os.path.exists('jsonfiles/tempID.json'):
            os.remove('jsonfiles/tempID.json')

    def test_check_location_conflict(self):
        from classroom import Classroom
        from course_section import CourseSection
        from course import Course

        classroom = Classroom(50, "A101")
        course = Course()
        course.set_course_code("CSE999")

        section1 = CourseSection("Monday", "09:00-10:00", 1, course, classroom, 30, None)
        classroom.add_course_section(section1)

        # Overlapping time
        section2 = CourseSection("Monday", "09:30-10:30", 2, course, classroom, 30, None)
        self.assertTrue(classroom.check_location_conflict(section2))

        # Different day
        section3 = CourseSection("Tuesday", "09:30-10:30", 3, course, classroom, 30, None)
        self.assertFalse(classroom.check_location_conflict(section3))

if __name__ == '__main__':
    unittest.main()
