from typing import List, Dict, TYPE_CHECKING

if TYPE_CHECKING:
    from course import Course
    from course_section import CourseSection
    from student import Student

class Transcript:
    def __init__(self, selected_courses: List['CourseSection'], verified_courses: List['CourseSection'], finished_courses: Dict['Course', float], student: 'Student'):
        self._selected_courses: List['CourseSection'] = selected_courses
        self._verified_courses: List['CourseSection'] = verified_courses
        self._finished_courses: Dict['Course', float] = finished_courses
        self._student: 'Student' = student

    def set_selected_courses(self, selected_course_sections: List['CourseSection']):
        self._selected_courses = selected_course_sections

    def set_verified_courses(self, verified_courses: List['CourseSection']):
        self._verified_courses = verified_courses

    def add_selected_course(self, section: 'CourseSection'):
        self._selected_courses.append(section)

    def get_finished_courses(self) -> Dict['Course', float]:
        return self._finished_courses

    def get_selected_courses(self) -> List['CourseSection']:
        return self._selected_courses

    def get_student(self) -> 'Student':
        return self._student

    def get_verified_courses(self) -> List['CourseSection']:
        return self._verified_courses

    def add_verified_course(self, verified_course: 'CourseSection'):
        self._verified_courses.append(verified_course)

    def remove_selected_course(self, rejected_course: 'CourseSection'):
        rejected_course_code = rejected_course.get_course().get_course_code()
        for i in self._selected_courses:
            if i.get_course().get_course_code() == rejected_course_code:
                self._selected_courses.remove(i)
                break

    def __str__(self):
        result = ""
        for course, grade in self._finished_courses.items():
            result += f"Course: {course.get_name()}, Grade: {grade}\n"
        return result
