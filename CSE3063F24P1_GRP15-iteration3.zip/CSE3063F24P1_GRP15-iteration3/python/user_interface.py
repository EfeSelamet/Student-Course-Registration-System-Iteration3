from typing import List
import logging
import os






logging.basicConfig(filename="logs.txt", level=logging.DEBUG, 
                    format='%(asctime)s:%(levelname)s:%(message)s')

from login_system_controller import LoginSystemController
from registration_controller import RegistrationController
from verification_controller import VerificationController
from scheduler_controller import SchedulerController
from user_json_handler import UserJsonHandler
from admin_controller import Admin_Controller
import os


class UserInterface:
    def __init__(self):
        try:
            self.login_system_controller = LoginSystemController()
            self.registration_controller = RegistrationController()
        except Exception as e:
            print(e)
        

    def main(self):
        self.login_screen()

    def course_registration_screen(self):
        current_person = LoginSystemController.get_login_system().get_current_user()
        available_courses = RegistrationController.get_registration_controller().get_available_courses(current_person)
        selected_course_sections = []

        while True:
            print("Usage")
            print("----------------------------")
            print("To add a course, type: 'add course_index' (e.g., add 3)")
            print("To remove a course, type: 'remove course_index' (e.g., remove 2)")
            print("To confirm your courses, type: 'confirm'\n")

            print("Available Courses")
            print("----------------------------")
            course_section_numbers = []

            i=0
            for course in (available_courses):
                sections = course.get_course_sections()
                course_section_numbers.append(len(sections))
                
                for section in sections:
                    print(f"{i + 1}. {course.get_course_code()}.{section.get_section_number()} {course.get_name()}\n\t{section.get_day()}\n\t{section.get_hour()}\n")
                    i = i + 1

            print("\nSelected Courses")
            print("----------------------------")
            
            for i, section in enumerate(selected_course_sections):
                print(f"{i + 1}. {section.get_id()} {section.get_course().get_name()}\n\t{section.get_day()}\n\t{section.get_hour()}\n")

            input_command = input().split(" ")

            if len(input_command) == 1 and input_command[0] == "confirm":
                RegistrationController.get_registration_controller().send_selected_courses(selected_course_sections, current_person)
                break

            elif len(input_command) == 2:
                try:
                    course_index = int(input_command[1])
                except ValueError as e:
                    logging.error(e, exc_info=True)
                    print("Course index must be an integer")
                    continue

                if input_command[0] == "add":
                    found = False
                    for i, count in enumerate(course_section_numbers):
                        if course_index <= count:
                            selected_course = available_courses[i]
                            selected_section = selected_course.get_course_sections()[course_index - 1]
                            if selected_section.get_capacity() == selected_section.get_number_of_students():
                                print("Section is full. You have been added to the waiting list.")
                                RegistrationController.get_registration_controller().put_student_on_waiting_list(current_person, selected_section)
                                found = True
                                break
                            selected_course_sections.append(selected_section)
                            available_courses.remove(selected_course)
                            found = True
                            break
                        else:
                            course_index -= count

                    if not found:
                        print("Invalid course index.")
                        logging.error("Invalid course index", exc_info=True)
                elif input_command[0] == "remove":
                    course_index -= 1
                    if course_index >= len(selected_course_sections):
                        logging.error("Invalid course index.", exc_info=True)
                        print("Invalid course index.")
                        continue
                    course = selected_course_sections[course_index].get_course()
                    selected_course_sections.pop(course_index)
                    available_courses.append(course)

                else:
                    logging.error("Invalid input command:", exc_info=True)
                    print("Invalid input.")

            else:
                logging.error("Invalid input command:", exc_info=True)
                print("Invalid input.")

    def login_screen(self):
        from user_json_handler import UserJsonHandler
        username = ""
        password = ""
        
        while True:
            try:
                username = input("Please enter username: ")
                if not username.strip():
                    raise ValueError("Username cannot be empty or contain whitespace.")

                password = input("Please enter password: ")
                if not password.strip():
                    raise ValueError("Password cannot be empty.")

                if LoginSystemController.get_login_system().login(username, password):
                    user_id = LoginSystemController.get_login_system().get_current_user().get_id()
                    notifications = UserJsonHandler().pull_notifications(user_id)
                    for note in notifications:
                        print(note)
                    break
            except ValueError as e:
                logging.error(e, exc_info=True)
                print(f"Error: {e}")
        
                
        LoginSystemController.get_login_system().get_current_user().main_menu(self)

    def view_weekly_schedule(self, courses):
        schedule = [[["" for _ in range(2)] for _ in range(8)] for _ in range(5)]

        for course_section in courses:
            time_string = course_section.get_hour()
            start = int(time_string[6:8])
            length = start - int(time_string[:2]) + 1

            day_index = {
                "Monday": 0,
                "Tuesday": 1,
                "Wednesday": 2,
                "Thursday": 3,
                "Friday": 4
            }[course_section.get_day()]

            hour_index = start - 9 if start < 13 else start - 10

            for a in range(length):
                schedule[day_index][hour_index + a][0] = f"{course_section.get_course().get_course_code()}.{course_section.get_section_number()}"
                schedule[day_index][hour_index + a][1] = course_section.get_classroom().get_room_id()

        print("___________________________________________________________________________________________________________________")
        print(" schedule |09:00       |10:00       |11:00       |13:00       |14:00       |15:00       |16:00       |17:00       |")
        print("___________________________________________________________________________________________________________________")

        for i, day in enumerate(schedule):
            print(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"][i], end="  ")
            for hour in day:
                print(f"|{hour[0]:<12}", end="")
            print("|")

            print("          ", end="")
            for hour in day:
                print(f"|{hour[1]:<12}", end="")
            print("|")
            print("___________________________________________________________________________________________________________________")

    def student_main_screen(self):
        while True:
            print("1. Course registration screen")
            print("2. View weekly schedule")
            print("3. Transcript")
            print("4. Log out")
            print("\nSelect an operation:")

            try:
                index = int(input())
                if index not in [1, 2, 3, 4]:
                    raise ValueError("Invalid choice")
            except ValueError:
                logging.error("Invalid input for main screen operation.", exc_info=True)
                print("\nInvalid input.")
                continue

            student = LoginSystemController.get_login_system().get_current_user()

            if index == 1:
                self.course_registration_screen()
            elif index == 2:
                self.view_weekly_schedule(student.get_transcript().get_verified_courses())
            elif index == 3:
                print(student.get_transcript())
            elif index == 4:
                self.log_out()
                break

    def log_out(self):
        LoginSystemController.get_login_system().logout()
        self.login_screen()

    def advisor_main_screen(self):
        while True:
            print("1. Student course verification screen")
            print("2. Log out")
            print("\nSelect an operation:")

            try:
                index = int(input())
                if index not in [1, 2]:
                    raise ValueError("Invalid choice")
            except ValueError:
                logging.error("Invalid input for advisor main screen.", exc_info=True)
                print("\nInvalid input.")
                continue

            if index == 1:
                self.course_verification_screen()
            elif index == 2:
                self.log_out()
                break

    def course_verification_screen(self):
        advisor = LoginSystemController.get_login_system().get_current_user()
        verification_controller = VerificationController()
        print(verification_controller.view_student_list(advisor))

        verified_courses = []
        rejected_courses = []

        while(True):
            try:
                student_index = int(input()) - 1
            except ValueError:
                logging.error("Invalid course index input.", exc_info=True)
                print("Invalid input")
                return
            if(verification_controller.select_student(student_index, advisor)):
                break


        while True:
            print("Usage")
            print("----------------------------")
            print("To verify a course: 'verify course_index'")
            print("To reject a course: 'reject course_index'")
            print("To confirm choices: 'confirm'\n")
            print("Courses chosen by the student:")
            
            selected_list : str = verification_controller.view_selected_list()
            for (i,course) in enumerate(selected_list):
                if(i in verified_courses):
                    selected_list[i] = course + " (VERIFIED)"
                if(i in rejected_courses):
                    selected_list[i] = course + " (REJECTED)"

            input_command = input().split(" ")

            if len(input_command) == 1 and input_command[0] == "confirm":
                verification_controller.send_verified_courses(verified_courses)
                verification_controller.send_rejected_courses(rejected_courses)
                break

            elif len(input_command) == 2:
                try:
                    course_index = int(input_command[1]) - 1
                except ValueError:
                    print("Invalid input")
                    logging.error("Invalid course index input.", exc_info=True)
                    
                    continue

                if not (0 <= course_index < len(selected_list)):
                    print("Invalid index")
                    logging.error("Invalid course index input.", exc_info=True)
                    continue

                if input_command[0] == "verify":
                    if course_index not in verified_courses:
                        verified_courses.append(course_index)
                    if course_index in rejected_courses:
                        rejected_courses.remove(course_index)

                elif input_command[0] == "reject":
                    if course_index not in rejected_courses:
                        rejected_courses.append(course_index)
                    if course_index in verified_courses:
                        verified_courses.remove(course_index)

                else:
                    logging.error("Invalid input command: %s", input_command)
                    print("Invalid input.")

            else:
                logging.error("Invalid input command: %s", input_command)
                print("Invalid input.")

    def scheduler_main_screen(self):
        while True:
            print("1. Manage Courses")
            print("2. Log out")
            print("\nSelect an operation:")

            try:
                index = int(input())
                if index not in [1, 2]:
                    raise ValueError("Invalid choice")
            except ValueError:
                logging.error("Invalid input at scheduler main screen.", exc_info=True)
                print("\nInvalid input.")
                continue

            if index == 1:
                self.schedule_management_screen()
            elif index == 2:
                self.log_out()
                break

    def schedule_management_screen(self):
        while True:
            all_courses = RegistrationController.get_registration_controller().get_all_courses()
            print("Courses:")
            for i, course in enumerate(all_courses):
                print(f"{i + 1}. {course.get_course_code()} {course.get_name()}")
            print("Choose an option:")
            print("1. Edit section capacity")
            print("2. Edit section day/time")
            print("3. Edit section class")
            print("4. Add course section")
            print("5. Edit section lecturer")
            print("6. Log out")
            try:
                index = int(input())
                if index not in [1, 2, 3, 4,5,6]:
                    raise ValueError("Invalid choice")
            except ValueError:
                logging.error("Invalid input at schedule management screen.", exc_info=True)
                print("\nInvalid input.")
                continue
            if index == 1:
                self.edit_section_capacity_screen()
            elif index == 2:
                self.edit_section_day_time_screen()
            elif index == 3:
                self.edit_section_class_screen()
            elif index == 4:
                self.add_course_section_screen()
            elif index == 5:
                self.edit_lecturer_screen()
            elif index == 6:
                self.log_out()
                break

    def department_head_main_screen(self):
        while True:
            print("1. Manage course")
            print("2. Add course")
            print("3. Log out")
            print("\nSelect an operation:")

            try:
                index = int(input())
                if index not in [1,2,3]:
                    raise ValueError("Invalid choice")
                    
            except ValueError:
                print("\nInvalid input.")
                logging.error("Invalid input at department head main screen.", exc_info=True)
                continue

            if index == 1:
                self.schedule_management_screen()
            elif index == 2:
                self.course_adding_screen()
            elif index == 3:
                self.log_out()
                break

    def course_adding_screen(self):
        scheduler_controller = SchedulerController()
        course_code = input("Enter course code: ")
        course_name = input("Enter course name: ")
        prerequisites = input("Enter prerequisites (seperate with spaces): ").split()
        year = input("Enter year: ")
        credits = input("Enter credits: ")
        technical_elective = input("Enter if technical elective: (0 is not 1 is yes)")
       
        try:
            scheduler_controller.create_course(course_code, course_name, prerequisites,year, credits, technical_elective)
        except ValueError as e:
            logging.error(e, exc_info=True)
            print(e)
            logging.error("Error creating course.", exc_info=True)
    def edit_section_capacity_screen(self):
        scheduler_controller = SchedulerController()
        course_code = input("Enter course code: ")
        section_number = input("Enter section number: ")
        capacity = input("Enter new capacity: ")
        try:
            scheduler_controller.edit_section_capacity(course_code, section_number, capacity)
        except ValueError as e:
            logging.error(e, exc_info=True)
            print(e)

    def edit_lecturer_screen(self):
        try:
            scheduler_controller = SchedulerController()
            course_code = input("Enter course code: ")
            section_number = int(input("Enter section number: "))
            lecturer_ID = input("Enter lecturer ID: ")
            scheduler_controller.edit_section_lecturer(course_code, section_number, lecturer_ID)            
        except ValueError as e:
            logging.error(e, exc_info=True)
            print(e)
        
    def edit_section_day_time_screen(self):
        scheduler_controller = SchedulerController()
        course_code = input("Enter course code: ")
        section_number = input("Enter section number: ")
        day = input("Enter new day: ")
        time = input("Enter new time: ")
        try:
            scheduler_controller.edit_section_day_time(course_code, section_number, day, time)
        except ValueError as e:
            logging.error(e, exc_info=True)
            print(e)
    def edit_section_class_screen(self):
        scheduler_controller = SchedulerController()
        course_code = input("Enter course code: ")
        section_number = input("Enter section number: ")
        classroom = input("Enter new classroom: ")
        try:
            scheduler_controller.edit_section_class(course_code, section_number, classroom)
        except ValueError as e:
            logging.error(e, exc_info=True)
            print(e)
    def add_course_section_screen(self):
        scheduler_controller = SchedulerController()
        course_index_str = input("Enter course index: ")
        try:
            course_index = int(course_index_str)
        except ValueError:
            logging.error("Invalid course index.", exc_info=True)
            print("Invalid course index.")
            return
        classroom = input("Enter classroom: ")
        hour = input("Enter hour: ")
        day = input("Enter day: ")
        try:
            scheduler_controller.add_course_section(course_index, classroom, hour, day)
        except ValueError as e:
            logging.error(e, exc_info=True)
            print(e)
    def admin_main_screen(self):
        while True:
            print("1. add new person")
            print("2. Log out")
            print("\nSelect an operation:")

            try:
                index = int(input())
                if index not in [1,2]:
                    raise ValueError("Invalid choice")
            except ValueError:
                print("\nInvalid input.")
                continue

            if index == 1:
                self.new_person_screen()
            elif index == 2:
                self.log_out()
                break
    
    def new_person_screen(self):
        while True:
            print("Enter the type of person who will be added to the system:")
            print("1. Student")
            print("2. Advisor")
            print("3. Scheduler")
            print("4. Dep Head")
            print("5. Log out")
            try:
                index = int(input())
                if index not in [1, 2, 3, 4,5]:
                    raise ValueError("Invalid choice")
            except ValueError:
                print("\nInvalid input.")
                continue
            if index == 1:
                self.new_student_screen()
            elif index == 2:
                self.new_advisor_screen()
            elif index == 3:
                self.new_scheduler_screen()
            elif index == 4:
                self.new_dep_head_screen()
            elif index == 5:
                self.log_out()
                break
    
    def new_student_screen(self):
        user_json_handler = UserJsonHandler()
        admin_con = Admin_Controller()
        user_ID = admin_con.check_user()
        password = input("Enter password: ")
        student_name = input("Enter Student name")
        advisor_ID = admin_con.find_user()

        try:
            username = str("o" + user_ID)
            admin_con.add_user(username, password, user_ID)
            admin_con.add_Student(student_name, user_ID, advisor_ID)
        except ValueError as e:
            print(e)

    def new_advisor_screen(self):
        user_json_handler = UserJsonHandler()
        admin_con = Admin_Controller()
        user_ID = admin_con.check_user()
        password = input("Enter password: ")
        name = input("Enter Advisor name")

        try:
            username = str("o" + user_ID)
            admin_con.add_user(username, password, user_ID)
            admin_con.add_advisor(name,user_ID)
        except ValueError as e:
            print(e)

    def new_scheduler_screen(self):
        user_json_handler = UserJsonHandler()
        admin_con = Admin_Controller()
        user_ID = admin_con.check_user()
        password = input("Enter password: ")
        name = input("Enter Scheduler name")

        try:
            username = str("o" + user_ID)
            admin_con.add_user(username, password, user_ID)
            admin_con.add_Schedluer(name,user_ID)
        except ValueError as e:
            print(e)

    def new_dep_head_screen(self):
        user_json_handler = UserJsonHandler()
        admin_con = Admin_Controller()
        user_ID = admin_con.check_user()
        password = input("Enter password: ")
        name = input("Enter Department Head name")

        try:
            username = str("o" + user_ID)
            admin_con.add_user(username, password, user_ID)
            admin_con.add_Dep_head(name,user_ID)
        except ValueError as e:
            print(e)
    
    def student_affair_menu(self):
        while True:
            print("1. Send notification")
            print("2. Log out")

            try:
                index = int(input())
                if index not in [1,2]:
                    raise ValueError("Invalid choice")
            except ValueError:
                print("\nInvalid input.")
                continue

            if index == 1:
                self.notification_menu()
            elif index == 2:
                self.log_out()
                break

    def notification_menu(self):
        while True:
            print("1. Send notification to a specific student")
            print("2. Send notification to all students")

            try:
                index = int(input())
                if index not in [1,2]:
                    raise ValueError("Invalid choice")
            except ValueError:
                print("\nInvalid input.")
                continue

            if index == 1:
                print("Enter student number:")
                try:
                    id = input()
                except:
                    print("Invalid student number")
                    continue

                print("Enter notification message:")
                try:
                    message = input()
                except ValueError:
                    print("\nInvalid input.")
                    continue
                self.login_system_controller.send_notification_to_id(id, message)
                break 

            elif index == 2:
                print("Enter notification message:")
                try:
                    message = input()
                except ValueError:
                    print("\nInvalid input.")
                    continue

                self.login_system_controller.send_notification_to_all(message)
                break 
                
if __name__ == "__main__":
    ui = UserInterface()
    ui.login_screen()