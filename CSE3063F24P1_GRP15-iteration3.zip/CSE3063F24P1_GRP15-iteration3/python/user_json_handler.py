import json
import logging
import os
from typing import List

# Ensure the logs directory exists


# Configure logging to write to a file named 'logs'
logging.basicConfig(filename="logs.txt", level=logging.ERROR, 
                    format='%(asctime)s:%(levelname)s:%(message)s')

from course_section import CourseSection
from student import Student

class UserJsonHandler:
    
    def __init__(self):
        self._parameters: str = "jsonfiles/parameters.json"
    
    def check_user(self, user_name: str, password: str) -> str:
        try:
            with open(self._parameters, 'r') as reader:
                json_content = reader.read()
            
            users_array = json.loads(json_content)

            for user in users_array:
                stored_username = user["username"]
                stored_password = user["password"]

                if stored_username == user_name and stored_password == password:
                    return user["userId"]

        except FileNotFoundError:
            # exc_info=True includes the traceback information in the log message
            logging.error("File not found", exc_info=True)
        
        return ""
    
    def write_all_selected_courses(self, student: 'Student', cs_list: List['CourseSection']):
        for cs in cs_list:
            self.write_selected_courses_section(student, cs)

    def write_selected_courses_section(self, student: 'Student', cs: 'CourseSection'):
        id = student.get_id()
        file_path = f"jsonfiles/{id}.json"
        
        try:
            with open(file_path, 'r') as reader:
                json_content = reader.read()

            json_object = json.loads(json_content)

            selected_course_sections = json_object["selectedCourseSections"]
            selected_course_sections.append(cs.get_id())

            student.get_transcript().add_selected_course(cs)

            with open(file_path, 'w') as file:
                json.dump(json_object, file, indent=4)

        except IOError as e:
            logging.error(e, exc_info=True)

    def write_verified_course_section(self, student: 'Student', cs: 'CourseSection'):
        id = student.get_id()
        file_path = f"jsonfiles/{id}.json"

        try:
            with open(file_path, 'r') as reader:
                json_content = reader.read()

            json_object = json.loads(json_content)

            verified_course_sections = json_object["verifiedCourseSections"]
            verified_course_sections.append(cs.get_id())

            with open(file_path, 'w') as file:
                json.dump(json_object, file, indent=4)

        except IOError as e:
            logging.error(e, exc_info=True)

    def remove_selected_course_section(self, student: 'Student', cs: 'CourseSection'):
        id = student.get_id()
        file_path = f"jsonfiles/{id}.json"

        try:
            with open(file_path, 'r') as reader:
                json_content = reader.read()

            json_object = json.loads(json_content)

            selected_course_sections = json_object["selectedCourseSections"]
            course_to_remove = cs.get_id()

            for i in range(len(selected_course_sections)):
                if selected_course_sections[i] == course_to_remove:
                    selected_course_sections.pop(i)
                    break

            with open(file_path, 'w') as file:
                json.dump(json_object, file, indent=4)

        except IOError as e:
            logging.error(e, exc_info=True)

    def retrieve_info(self, id: str) -> List[str]:
        file_name = f"jsonfiles/{id}.json"
        infos = []

        try:
            with open(file_name, 'r') as reader:
                json_content = reader.read()

            json_object = json.loads(json_content)

            type_ = json_object["type"]
            infos.append(type_)

            if type_ == "student":
                infos.append(json_object["name"])
                infos.append(json_object["advisorId"])
                selected_courses = json_object["selectedCourseSections"]
                infos.append(",".join(selected_courses))

                verified_courses = json_object["verifiedCourseSections"]
                infos.append(",".join(verified_courses))

                finished_courses = json_object["finishedCourses"]
                infos.append(",".join(finished_courses))

            elif type_ == "advisor":
                infos.append(json_object["name"])

                student_array = json_object["students"]
                infos.append(",".join(student_array))

            elif type_ == "scheduler":
                infos.append(json_object["name"])
            
            elif type_ == "dep_head":
                infos.append(json_object["name"])
            
            elif type_ == "admin":
                infos.append(json_object["name"])

            elif type_ == "student_affairs":
                infos.append(json_object["name"])
                #TODO

            elif type_ == "student_affairs":
                infos.append(json_object["name"])
                #TODO

        except FileNotFoundError:
            # exc_info=True includes the traceback information in the log message
            logging.error("File not found", exc_info=True)

        return infos

    def write_notification(self, student: 'Student', message: str):
        id = student.get_id()
        file_path = f"jsonfiles/{id}.json"
        try:
            with open(file_path, 'r') as reader:
                json_content = json.load(reader)

            if "notifications" not in json_content:
                json_content["notifications"] = []
            json_content["notifications"].append(message)

            with open(file_path, 'w') as file:
                json.dump(json_content, file, indent=4)
        except IOError as e:
            logging.error(e, exc_info=True)

    def pull_notifications(self, student_id: str) -> List[str]:
        file_path = f"jsonfiles/{student_id}.json"
        notifications = []
        try:
            with open(file_path, 'r') as reader:
                json_content = json.load(reader)

            if "notifications" in json_content:
                notifications = json_content["notifications"]
                json_content["notifications"] = []

            with open(file_path, 'w') as file:
                json.dump(json_content, file, indent=4)
        except IOError as e:
            logging.error(e, exc_info=True)
        return notifications
    
    def get_all_student_ids(self) ->List[str]:
        try:
            with open(self._parameters, "r") as file:
                data = json.load(file)

            # Get all usernames
            usernames = [item["username"] for item in data]
            student_numbers : List[str] = [username[1:] for username in usernames]
            for number in student_numbers:
                if not number.startswith("1"): # all student numbers starts with 1
                    student_numbers.remove(number)

            return student_numbers
        except IOError as e:
            logging.error(e,exec_info=True)
    
    def create_dep_head(self, name: 'str', dep_ID: 'str'):
        dep_head_data = {
            "type": "dep_head",
            "name": name
        }

        # Define the file path
        file_path = f"jsonfiles/{dep_ID}.json"
        try:
            # Write the department head data to a JSON file
            with open(file_path, 'w') as json_file:
                json.dump(dep_head_data, json_file, indent=2)
        except Exception as e:
            logging.error(f"Error creating department head: {e}",exec_info=True)
            
    def create_scheduler(self, name: 'str', scheduler_ID: 'str'):
        scheduler_data = {
            "type": "scheduler",
            "name": name
        }

        # Define the file path
        file_path = f"jsonfiles/{scheduler_ID}.json"
        try:
            
            with open(file_path, 'w') as json_file:
                json.dump(scheduler_data, json_file, indent=2)
        except Exception as e:
            logging.error(f"Error creating scheduler: {e}", exec_info=True)

    def create_student(self, name: 'str', student_ID: 'str', advisor_ID: 'str'):
        student_data = {
            "finishedCourses": [],
            "advisorId": advisor_ID,
            "name": name,
            "verifiedCourseSections": [],
            "type": "student",
            "selectedCourseSections": []
        }

        # Define the file path
        file_path = f"jsonfiles/{student_ID}.json"

        try:
            with open(file_path, 'w') as json_file:
                json.dump(student_data, json_file, indent=2)
            advisor_file_path = f"jsonfiles/{advisor_ID}.json"
        
            with open(advisor_file_path, "r") as file:
                advisor_json_content = json.load(file)
            advisor_json_content["students"].append(student_ID)

            with open(advisor_file_path, "w") as file:
                json.dump(advisor_json_content, file, indent=2)

        except Exception as e:
            logging.error(f"Error adding new student to advisor json: {e}",exec_info=True)

    def create_advisor(self, name: 'str',  advisor_ID: 'str'):
        advisor_data = {
            "type": "advisor",
            "name": name,
            "advisorId": advisor_ID,
            "students": []
        }

        # Define the file path
        file_path = f"jsonfiles/{advisor_ID}.json"

        # Write the department head data to a JSON file
        with open(file_path, 'w') as json_file:
            json.dump(advisor_data, json_file, indent=2)
            
    def create_parameter(self, username: 'str', password: 'str', user_ID: 'str'):
        file_path = f"jsonfiles/parameters.json"
        try:
            with open(file_path, "r") as file:
                json_content = json.load(file)
            json_content.append({
                "username": username,
                "password": password,
                "userId": user_ID
                })

            with open(file_path, "w") as file:
                json.dump(json_content, file, indent=2)
        except Exception as e:
            logging.error(f"Error adding new person to parameters json: {e}",exec_info=True)