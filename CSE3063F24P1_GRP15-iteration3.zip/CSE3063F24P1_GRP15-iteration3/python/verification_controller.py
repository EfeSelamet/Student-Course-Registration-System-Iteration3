from typing import List

from advisor import Advisor
from login_system_controller import LoginSystemController

class VerificationController:

    def __init__(self):
        pass

    def view_student_list(self, advisor: 'Advisor') -> str:
        student_list = ""
        number = 1
        list_of_students = advisor.get_student_list()
        for student in list_of_students:
            student_list += f"{number}. {student.get_id()} {student.get_full_name()}\n"
            number += 1
        return student_list

    def select_student(self, index:int, advisor: 'Advisor'):
        list_of_students = advisor.get_student_list()
        if(index < 0 or index > len(list_of_students)):
            return False
        else:
            self.selected_student = list_of_students[index]
            return True

    def view_selected_list(self) -> List[str]:
        selected_courses = []

        list_of_selected_courses = self.selected_student.retrieve_selected_courses()
        number = 1
        for course in list_of_selected_courses:
            selected_courses.append(f"{number}. {course.get_course().get_course_code()} {course.get_course().get_name()} " \
                                 f"{course.get_section_number()} {course.get_day()} {course.get_hour()} {course.get_classroom().get_room_id()}\n")
            number += 1
        return selected_courses

    def send_verified_courses(self, verified_courses: List[int]):
        advisor = LoginSystemController.get_login_system().get_current_user()

        selected_student = self.selected_student

        transcript = selected_student.get_transcript()

        list_of_selected_courses = selected_student.retrieve_selected_courses()

        list_of_verified_courses = [list_of_selected_courses[course_section] for course_section in verified_courses]
        
        advisor.send_verified_courses(transcript, list_of_verified_courses)

    def send_rejected_courses(self, rejected_courses: List[int]):
        advisor = LoginSystemController.get_login_system().get_current_user() 

        selected_student = self.selected_student

        transcript = selected_student.get_transcript()

        list_of_selected_courses = selected_student.retrieve_selected_courses()

        list_of_rejected_courses = [list_of_selected_courses[course_section] for course_section in rejected_courses]
        
        advisor.send_rejected_courses(transcript, list_of_rejected_courses)
